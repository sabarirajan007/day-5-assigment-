/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 1024

int main(void) {
    FILE *input_file = fopen("input.txt", "r");
    FILE *error_log_file = fopen("error_log.txt", "w");

    if (input_file == NULL) {
        printf("Error: Failed to open input.txt\n");
        exit(1);
    }

    if (error_log_file == NULL) {
        printf("Error: Failed to open error_log.txt\n");
        exit(1);
    }

    char line[MAX_LINE_LENGTH];

    while (fgets(line, MAX_LINE_LENGTH, input_file)) {
        if (strstr(line, "error") != NULL) {
            fputs(line, error_log_file);
        }
    }

    fclose(input_file);
    fclose(error_log_file);

    // Now, read and print the contents of error_log.txt
    error_log_file = fopen("error_log.txt", "r");

    if (error_log_file == NULL) {
        printf("Error: Failed to open error_log.txt\n");
        exit(1);
    }

    printf("Contents of error_log.txt:\n");

    while (fgets(line, MAX_LINE_LENGTH, error_log_file)) {
        printf("%s", line);
    }

    fclose(error_log_file);

    return 0;
}
